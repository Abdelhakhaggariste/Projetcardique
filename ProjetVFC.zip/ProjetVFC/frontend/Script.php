<?php
$servername = "localhost"; // ou votre serveur de base de données
$username = "root"; // nom d'utilisateur de la base de données
$password = ""; // mot de passe de la base de données
$dbname = "cardiac_data"; // nom de votre base de données

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifiez la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}
?>
