<?php
// Démarrer la session
session_start();

// Vérifier si le médecin est connecté, sinon rediriger vers la page de connexion
if (!isset($_SESSION['medecin_id'])) {
    header("Location: login_doctor.php");
    exit();
}

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier contient la connexion à la base de données

// Récupérer les informations du médecin connecté
$medecin_id = $_SESSION['medecin_id'];

$query = "SELECT nom, prenom, specialite FROM medecin WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $medecin_id);
$stmt->execute();
$stmt->bind_result($nom, $prenom, $specialite);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Médecin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1, h2 {
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #2980b9;
            color: white;
        }

        a {
            color: #2980b9;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin: 10px 0;
        }

        .logout-link {
            color: red;
        }
    </style>
</head>
<body>
    <h1>Bienvenue, Dr. <?php echo htmlspecialchars($nom) . ' ' . htmlspecialchars($prenom); ?></h1>
    <p>Spécialité : <?php echo htmlspecialchars($specialite); ?></p>

    <h2>Liste des Patients</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Date de Naissance</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Récupérer la liste des patients
            $query = "SELECT id, nom, prenom, date_naissance, email FROM patient";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['nom']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['prenom']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['date_naissance']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td><a href='view_patient.php?id=" . htmlspecialchars($row['id']) . "'>Voir Détails</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>Aucun patient trouvé.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <h2>Autres Actions</h2>
    <ul>
        
        <li><a class="logout-link" href="logout.php">Se déconnecter</a></li>
    </ul>

    <!-- Si vous avez des notifications, vous pouvez les afficher ici -->
    <!-- <h2>Notifications</h2>
    <p>Aucune nouvelle notification.</p> -->
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>
