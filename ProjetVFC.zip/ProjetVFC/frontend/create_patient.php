<?php
// Activer le rapport d'erreur
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier établit la connexion à votre base de données

$message = '';
$messageClass = '';

// Vérifiez si la méthode de requête est POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $date_naissance = $_POST['date_naissance'];
    $sexe = $_POST['sexe'];
    $adresse = $_POST['adresse'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    
    // Vérifiez si le mot de passe est défini
    if (isset($_POST['mot_de_passe']) && !empty($_POST['mot_de_passe'])) {
        $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT); // Hachage du mot de passe
    } else {
        $message = "Le mot de passe ne peut pas être vide.";
        $messageClass = 'error'; // Classe pour le message d'erreur
    }

    // Insérer un nouveau patient dans la base de données si le mot de passe est valide
    if (!empty($mot_de_passe)) {
        $query = "INSERT INTO patient (nom, prenom, date_naissance, sexe, adresse, telephone, email, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssss", $nom, $prenom, $date_naissance, $sexe, $adresse, $telephone, $email, $mot_de_passe);

        // Exécuter l'instruction
        if ($stmt->execute()) {
            $message = "Compte patient créé avec succès.";
            $messageClass = 'success'; // Classe pour le message de succès
        } else {
            $message = "Erreur d'exécution : " . $stmt->error; // Affichage de l'erreur d'exécution
            $messageClass = 'error'; // Classe pour le message d'erreur
        }
        $stmt->close();
    }
}

// Fermer la connexion
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un Compte Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 30%;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="date"],
        select {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #3498db;
        }
        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .success {
            color: blue; /* Couleur du message de succès */
        }
        .error {
            color: red; /* Couleur du message d'erreur */
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Créer un Compte Patient</h2>
        
        <?php if ($message): ?>
            <div class="message <?= $messageClass; ?>"><?= htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form action="create_patient.php" method="POST">
            <input type="text" name="nom" placeholder="Nom" required>
            <input type="text" name="prenom" placeholder="Prénom" required>
            <input type="date" name="date_naissance" required>
            <select name="sexe" required>
                <option value="">Sélectionnez le sexe</option>
                <option value="M">Homme</option>
                <option value="F">Femme</option>
            </select>
            <input type="text" name="adresse" placeholder="Adresse" required>
            <input type="text" name="telephone" placeholder="Téléphone" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
            <button type="submit">Créer Compte</button>
        </form>

        <button onclick="window.location.href='login_patient.php'" style="margin-top: 20px;">Se Connecter</button>
    </div>

</body>
</html>
