<?php
// Activer le rapport d'erreur
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

// Initialiser le message
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtenir les données du formulaire
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $specialite = $_POST['specialite'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hachage du mot de passe pour des raisons de sécurité

    // Insérer un nouveau médecin dans la base de données
    $query = "INSERT INTO medecin (nom, prenom, specialite, telephone, email, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    // Vérifiez si prepare() a réussi
    if ($stmt) {
        $stmt->bind_param("ssssss", $nom, $prenom, $specialite, $telephone, $email, $password);

        // Exécuter l'instruction
        if ($stmt->execute()) {
            $message = "Compte médecin créé avec succès.";
        } else {
            $message = "Erreur d'exécution : " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Erreur lors de la préparation de la requête : " . $conn->error;
    }
}

// Fermer la connexion
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un Compte Médecin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 40%;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #3498db;
        }

        .message {
            text-align: center;
            color: green;
            font-weight: bold;
        }

        .error {
            text-align: center;
            color: red;
            font-weight: bold;
        }

        .back-button {
            margin-top: 20px;
            text-align: center;
        }

        .back-button a {
            text-decoration: none;
            color: white;
            background-color: #e74c3c; /* Red color */
            padding: 10px;
            border-radius: 4px;
        }

        .back-button a:hover {
            background-color: #c0392b; /* Darker red on hover */
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Créer un Compte Médecin</h2>

        <!-- Affichage du message de succès ou d'erreur -->
        <?php if ($message): ?>
            <div class="<?= strpos($message, 'succès') !== false ? 'message' : 'error'; ?>">
                <?= $message; ?>
            </div>
        <?php endif; ?>

        <form action="create_doctor.php" method="POST">
            <input type="text" name="nom" placeholder="Nom" required>
            <input type="text" name="prenom" placeholder="Prénom" required>
            <input type="text" name="specialite" placeholder="Spécialité" required>
            <input type="text" name="telephone" placeholder="Téléphone" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Mot de passe" required>
            <button type="submit">Créer un compte</button>
        </form>

        <!-- Bouton de retour à la page de connexion -->
        <div class="back-button">
            <a href="login_doctor.php">Retour à la page de connexion</a>
        </div>
    </div>

</body>
</html>
