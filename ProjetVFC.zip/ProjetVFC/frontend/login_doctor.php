<?php
// Activer le rapport d'erreur
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$message = '';

// Vérifiez si la méthode de requête est POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Requête pour récupérer le mot de passe haché de l'utilisateur
    $query = "SELECT mot_de_passe, id FROM medecin WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($hashed_password, $medecin_id);
    $stmt->fetch();
    $stmt->close();

    // Vérifier le mot de passe
    if (password_verify($password, $hashed_password)) {
        // Stocker l'ID dans la session
        session_start();
        $_SESSION['medecin_id'] = $medecin_id;

        echo "<script>alert('Connexion réussie ! Redirection vers le tableau de bord.');</script>";
        header("Location: doctor_dashboard.php"); // Assurez-vous que ce fichier existe
        exit();
    } else {
        $message = "Mot de passe incorrect.";
    }
}

// Fermer la connexion
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Médecin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 30%;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #3498db;
        }
        .message {
            text-align: center;
            color: red;
            font-weight: bold;
        }
        .register-link {
            text-align: center;
            margin-top: 20px;
        }
        .register-link a {
            text-decoration: none;
            color: #2980b9;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .home-link {
            text-align: center;
            margin-top: 20px;
        }
        .home-link a {
            text-decoration: none;
            color: #2980b9;
        }
        .home-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Connexion Médecin</h2>
        
        <?php if ($message): ?>
            <div class="message"><?= $message; ?></div>
        <?php endif; ?>

        <form action="login_doctor.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Mot de passe" required>
            <button type="submit">Se connecter</button>
        </form>

        <div class="register-link">
            <a href="create_doctor.php">Créer un compte médecin</a>
        </div>

        <!-- Lien vers la page d'accueil -->
        <div class="home-link">
            <a href="index.html">Retour à la page d'accueil</a>
        </div>
    </div>
</body>
</html>
