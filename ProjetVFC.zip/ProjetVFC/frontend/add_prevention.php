<?php
// Démarrer la session
session_start();

// Vérifier si le médecin est connecté, sinon rediriger vers la page de connexion
if (!isset($_SESSION['medecin_id'])) {
    header("Location: login_doctor.php");
    exit();
}

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier contient la connexion à la base de données

// Vérifier si l'ID du patient est passé dans l'URL
if (!isset($_GET['id'])) {
    echo "ID du patient manquant.";
    exit();
}

$patient_id = $_GET['id'];

// Assurez-vous que l'ID est valide
if (!is_numeric($patient_id)) {
    echo "ID du patient invalide.";
    exit();
}

// Traiter le formulaire d'ajout de prévention
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $prevention_text = $_POST['prevention_text'];

    // Vérifier que le champ texte n'est pas vide
    if (!empty($prevention_text)) {
        // Préparer la requête d'insertion
        $query = "INSERT INTO prevention (patient_id, prevention_text) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $patient_id, $prevention_text);

        // Exécuter la requête
        if ($stmt->execute()) {
            echo "<div style='color: green;'>Conseil de prévention ajouté avec succès.</div>";
        } else {
            echo "<div style='color: red;'>Erreur lors de l'ajout : " . $stmt->error . "</div>";
        }
        $stmt->close();
    } else {
        echo "<div style='color: red;'>Le texte de prévention ne peut pas être vide.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Conseil de Prévention</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        h1 {
            color: #007BFF;
        }
        form {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: white;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        a {
            display: inline-block;
            margin-top: 10px;
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>Ajouter un Conseil de Prévention pour le Patient</h1>

    <form action="add_prevention.php?id=<?php echo $patient_id; ?>" method="post">
        <div>
            <label for="prevention_text">Conseil de Prévention :</label>
            <textarea id="prevention_text" name="prevention_text" rows="4" cols="50" required></textarea>
        </div>
        <div>
            <button type="submit">Ajouter</button>
        </div>
    </form>

    <a href="view_patient.php?id=<?php echo $patient_id; ?>">Retour aux Détails du Patient</a>
</body>
</html>

<?php
// Fermer la connexion
$conn->close();
?>
