document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('#heartRateTable tbody');
    const ctx = document.getElementById('heartRateChart').getContext('2d');

    // Fetch heart rate data from backend (you can adjust the API endpoint)
    fetch('fetch_heart_rate_data.php?patient_id=1') // Adjust patient ID dynamically
        .then(response => response.json())
        .then(data => {
            const labels = [];
            const heartRateValues = [];

            // Populate the table and chart data
            data.forEach(entry => {
                // Create table row
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${entry.date}</td>
                    <td>${entry.time}</td>
                    <td>${entry.value}</td>
                `;
                tableBody.appendChild(row);

                // Prepare chart data
                labels.push(`${entry.date} ${entry.time}`);
                heartRateValues.push(entry.value);
            });

            // Create line chart using Chart.js
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Heart Rate (bpm)',
                        data: heartRateValues,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: {
                            display: true
                        },
                        y: {
                            beginAtZero: false,
                            min: 40, // Adjust based on heart rate range
                            max: 200 // Adjust based on heart rate range
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching heart rate data:', error));
});
