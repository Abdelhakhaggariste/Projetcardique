<?php
// Démarrer la session
session_start();

// Vérifier si le médecin est connecté
if (!isset($_SESSION['medecin_id'])) {
    header("Location: login_doctor.php");
    exit();
}

// Inclure la connexion à la base de données
include 'Script.php'; 

// Vérifier si l'ID du patient est passé dans l'URL
if (!isset($_GET['id'])) {
    echo "ID du patient manquant.";
    exit();
}

$patient_id = $_GET['id'];

// Récupérer les informations du patient
$query = "SELECT nom, prenom, date_naissance, email FROM patient WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$stmt->bind_result($nom, $prenom, $date_naissance, $email);
$stmt->fetch();
$stmt->close();

// Vérifier si le patient existe
if (!$nom) {
    echo "Patient introuvable.";
    exit();
}

// Récupérer les données de fréquence cardiaque du patient
$query = "SELECT date, heure, valeur FROM heart_rate WHERE patient_id = ? ORDER BY date DESC, heure DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

// Préparer les données pour Chart.js
$heart_rate_data = [];
$timestamps = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $heart_rate_data[] = $row['valeur'];
        $timestamps[] = $row['date'] . ' ' . $row['heure'];
    }
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Patient</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .add-prevention {
            text-align: right; /* Aligne le texte à droite */
            margin-bottom: 10px; /* Espacement sous le bouton */
        }

        .add-prevention a {
            background-color: #4CAF50; /* Couleur de fond */
            color: white; /* Couleur du texte */
            padding: 10px 15px; /* Espacement intérieur */
            text-decoration: none; /* Supprime le soulignement */
            border-radius: 5px; /* Coins arrondis */
            transition: background-color 0.3s; /* Transition pour effet au survol */
        }

        .add-prevention a:hover {
            background-color: #45a049; /* Couleur de fond au survol */
        }
    </style>
</head>
<body>
    <h1>Détails du Patient : <?php echo htmlspecialchars($nom) . ' ' . htmlspecialchars($prenom); ?></h1>
    <p>Date de Naissance : <?php echo htmlspecialchars($date_naissance); ?></p>
    <p>Email : <?php echo htmlspecialchars($email); ?></p>

    <!-- Lien pour ajouter une prévention -->
    <div class="add-prevention">
        <a href="add_prevention.php?id=<?php echo htmlspecialchars($patient_id); ?>">Ajouter une Prévention</a>
    </div>

    <h2>Données de Fréquence Cardiaque</h2>
    <canvas id="heartRateChart" width="400" height="200"></canvas>

    <a href="doctor_dashboard.php">Retour au Tableau de Bord</a>

    <script>
        // Convertir les données PHP en JSON pour Chart.js
        var heartRateData = <?php echo json_encode($heart_rate_data); ?>;
        var timestamps = <?php echo json_encode($timestamps); ?>;

        // Configurer le graphique avec Chart.js
        var ctx = document.getElementById('heartRateChart').getContext('2d');
        var heartRateChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: timestamps,
                datasets: [{
                    label: 'Fréquence Cardiaque (BPM)',
                    data: heartRateData,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2,
                    fill: false,
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Temps'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Fréquence Cardiaque (BPM)'
                        },
                        beginAtZero: false
                    }
                }
            }
        });
    </script>
</body>
</html>
