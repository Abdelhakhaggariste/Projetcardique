<?php
// Activer le rapport d'erreur
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure la connexion à la base de données
include 'Script.php'; // Assurez-vous que ce fichier établit la connexion à votre base de données

$message = '';

// Vérifiez si la méthode de requête est POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $mot_de_passe = $_POST['mot_de_passe'];

    // Préparez la requête pour récupérer l'utilisateur
    $query = "SELECT id, mot_de_passe FROM patient WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Vérifiez si l'utilisateur existe
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        // Vérifiez le mot de passe
        if (password_verify($mot_de_passe, $hashed_password)) {
            // Démarrer la session et enregistrer l'ID de l'utilisateur
            session_start();
            $_SESSION['patient_id'] = $id;

            // Redirigez vers le tableau de bord du patient
            header("Location: patient_dashboard.php");
            exit();
        } else {
            $message = "Mot de passe incorrect.";
        }
    } else {
        $message = "Aucun compte trouvé avec cet email.";
    }

    $stmt->close();
}

// Fermer la connexion
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 30%;
            margin: 100px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #3498db;
        }
        .message {
            text-align: center;
            color: red; /* Couleur du message d'erreur */
            font-weight: bold;
        }
        a {
            color: #2980b9;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Connexion Patient</h2>
        
        <?php if ($message): ?>
            <div class="message"><?= htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form action="login_patient.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
            <button type="submit">Se Connecter</button>
        </form>

        <p style="text-align: center;">Pas encore inscrit? <a href="create_patient.php">Créer un compte</a></p>
        
        <!-- Ajouter un lien vers la page d'accueil -->
        <p style="text-align: center;"><a href="index.html">Retour à la page d'accueil</a></p>
    </div>

</body>
</html>
