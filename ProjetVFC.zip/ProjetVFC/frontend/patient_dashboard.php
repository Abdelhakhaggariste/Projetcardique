<?php
// Démarrer la session
session_start();

// Vérifier si le patient est connecté, sinon rediriger vers la page de connexion
if (!isset($_SESSION['patient_id'])) {
    header("Location: login_patient.php");
    exit();
}

// Inclure la connexion à la base de données
include 'Script.php';

// Récupérer les informations du patient connecté
$patient_id = $_SESSION['patient_id'];
$query = "SELECT nom, prenom, date_naissance, sexe, email FROM patient WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$stmt->bind_result($nom, $prenom, $date_naissance, $sexe, $email);
$stmt->fetch();
$stmt->close();

// Récupérer les conseils de prévention
$preventions_query = "SELECT prevention_text FROM prevention WHERE patient_id = ?";
$preventions_stmt = $conn->prepare($preventions_query);
$preventions_stmt->bind_param("i", $patient_id);
$preventions_stmt->execute();
$preventions_result = $preventions_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Patient</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            color: #2c3e50;
        }
        h2 {
            color: #2980b9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2980b9;
            color: white;
        }
        .logout {
            text-align: right;
        }
        .logout a {
            color: #e74c3c;
            text-decoration: none;
            font-weight: bold;
        }
        .logout a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="logout">
        <a href="login_patient.php">Se déconnecter</a>
        
    </div>
    <h1>Bienvenue, <?php echo htmlspecialchars($nom) . ' ' . htmlspecialchars($prenom); ?></h1>
    <p>Date de Naissance: <?php echo htmlspecialchars($date_naissance); ?></p>
    <p>Sexe: <?php echo htmlspecialchars($sexe == 'M' ? 'Masculin' : 'Féminin'); ?></p>
    <p>Email: <?php echo htmlspecialchars($email); ?></p>

    <h2>Conseils de Prévention</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Conseil de Prévention</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($preventions_result->num_rows > 0): ?>
                <?php $id = 1; while ($row = $preventions_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $id++; ?></td>
                        <td><?php echo htmlspecialchars($row['prevention_text']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2">Aucun conseil de prévention trouvé.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
// Fermer la connexion
$conn->close();
?>

</body>
</html>
