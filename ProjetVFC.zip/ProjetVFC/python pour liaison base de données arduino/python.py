import serial
import mysql.connector
from datetime import datetime
import time

arduino_port = 'COM3'  # Changez ce port si nécessaire
baud_rate = 9600

# Connect to the Arduino
try:
    arduino = serial.Serial(arduino_port, baud_rate)
    print(f"Connected to Arduino on port {arduino_port}.")
except serial.SerialException as e:
    print(f"Error connecting to serial port: {e}")
    exit()

# Connect to MySQL database
try:
    bd = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Utilisez votre mot de passe de base de données
        database="cardiac_data"
    )
    cursor = bd.cursor()
    print("Connected to MySQL database successfully.")

    # Retrieve all patient IDs
    cursor.execute("SELECT id FROM patient")
    patient_ids = cursor.fetchall()
    print(f"Patient IDs retrieved: {patient_ids}")

    while True:
        if arduino.in_waiting > 0:
            data = arduino.readline().decode('utf-8').strip()
            print(f"Data received from Arduino: {data}")  # Print received data

            # Only process numeric data
            if "BPM:" in data:  # Check if data contains 'BPM:'
                heart_rate_value = int(data.split(":")[1])  # Extract numeric value
                current_date = datetime.now().strftime('%Y-%m-%d')
                current_time = datetime.now().strftime('%H:%M:%S')

                # Insert data for all patients
                for patient_id in patient_ids:
                    query = "INSERT INTO heart_rate (date, heure, valeur, patient_id) VALUES (%s, %s, %s, %s)"
                    values = (current_date, current_time, heart_rate_value, patient_id[0])

                    try:
                        cursor.execute(query, values)
                        bd.commit()
                        print(f"Data inserted for patient {patient_id[0]}: Date: {current_date}, Time: {current_time}, Value: {heart_rate_value}")
                    except mysql.connector.Error as err:
                        print(f"MySQL error: {err}")
            else:
                print(f"Invalid heart rate data: {data}")  # Display non-numeric data

        time.sleep(1)

except mysql.connector.Error as err:
    print(f"MySQL error: {err}")
finally:
    if bd.is_connected():
        cursor.close()
        bd.close()
    if 'arduino' in locals() and arduino.is_open:
        arduino.close()
